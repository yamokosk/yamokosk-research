function d = distanceFunc(p1,p2)
diff = p1 - p2;
d = diff' * diff;