function dist = newDist(d, old, new, cutting_dimension)
dist = d + new^2 - old^2;